package com.example.demo.layer4.exceptions;

public class DepartmentNotFoundException extends Exception {

	public DepartmentNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
