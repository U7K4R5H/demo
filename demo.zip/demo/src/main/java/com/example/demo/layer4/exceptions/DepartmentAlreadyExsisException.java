package com.example.demo.layer4.exceptions;

public class DepartmentAlreadyExsisException extends Exception {

	public DepartmentAlreadyExsisException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
